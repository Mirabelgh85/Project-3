# (Prosper Loan Data Exploration)
## by (Mirabel Sam)


## Dataset
The Prosper Loan data includes 113,937 loans with 81 variables on each loan. I am interested in knowing what features affect the loan transactions in the dataset.The features 'Term', 'LoanStatus', 'EmploymentStatus',  'StatedMonthlyIncome', 'TotalProsperLoans', 'OnTimeProsperPayments', 'LoanOriginalAmount' and 'ProsperScore' will be useful in my  data exploration.  


## Summary of Findings

The highest number of borrowers are employed followed by full time employed, self employed and then other employment status. Those whose employment status are not determined follow closely while those who are not employed, part-time employed and retired follow with the lowest numbers. Most of the loans given out have a Prosper score of 2, 4, 6 and 8 with the other ratings following closely. This implies the risk of the loan transaction is unpredictable. The amount given out regularly as loan is 5000 while the highest amount given out as loan is 35,000. Loan terms are mostly between 36 and 38 months and also between 57 and 60 months. A large group (more than 50,000) of borrowers currently have loans to pay off while about 3000 people have completed their loans. About 14000 people are taking loan for the first time and about 4000 people are taking loan for the second time. Some borrowers have taken loan for as many as five times.
The employed people pay their loans on time. Loans completed have higher ratings that is low risks followed by loans whose final payments are in progress for their Prosper score. The amount given out as loan hardly depends on the monthly income of the borrowers. Loan term also hardly depends on the monthly income of the borrowers.
Those who have completed their loans borrowed not more than 7000. Those who defaulted their loans borrowed between 6000 and 12,000 with most of these people being self employed. Those whose loans are past due borrowed between 6000 and 14,000 and most of these people have part time employment. People do not consider their monthly income before going in for loans. The highest amount of loans are borrowed by part-time employed people and their loans are past due.  


## Key Insights for Presentation

1. What is the highest amount of loan given out and how many people that amount?
2. Does the amount borrowed depend on the monthly income of borrower?
3. How many times can customers take the loan?